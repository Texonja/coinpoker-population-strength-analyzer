# CoinPoker Population Strength Report

The hand-level CSVs list the cards and actions behind each line.

## Filters
- **game_filter**: plo4
- **stake_filter**: PL25
- **date_from**: none
- **date_to**: none
- **min_stack_bb**: 40.0
- **hands_analyzed_after_filters**: 5278
- **postflop_known_line_records**: 1007
- **preflop_known_line_records**: 928

## Highlights from shown hands
1. Bluffs made up 24.2% of the shown hands in Triple barrel / bet-bet-bet. Check the blockers in those hands when reviewing calls.
2. Only 0.0% of the shown hands in River raise - paired board were bluffs.
3. In Turn check-raise, the hands shown were mostly made hands and draws. Weak hands were uncommon.
4. Made hands and draws accounted for 95.7% of the shown hands in Flop check-raise.
5. In Shown 3-bets, 49.2% of shown hands had at least three broadway cards.
6. AAxx made up 50.5% of the hands shown in Shown 4-bet+ ranges.

## River hand breakdown
The strength classes depend on the board. See the hand mix for each line.

| line | known_hands | read_label | confidence | river_board_family | river_board_family_distribution | river_plo_top_classes | river_bluff_pct | river_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| River probe after turn checks through | 110 | MIXED / BLUFFS PRESENT | GOOD | paired 56.4%; unpaired straight 27.3%; unpaired flush 16.4% | paired 56.4%; unpaired straight 27.3%; unpaired flush 16.4% | Thin value 34.5%; Bluff 29.1%; Practical nuts 12.7%; Close to nuts 9.1%; Low flush 7.3%; Weak straight 5.5%; Medium flush 1.8% | 29.1 | 100.0 | River probe after turn checks through had 110 shown hands. Most common river classes were Thin value 34.5%; Bluff 29.1%; Practical nuts 12.7%; Close to nuts 9.1%; Low flush 7.3%; Weak straight 5.5%; Medium flush 1.8%. Bluffs made up 29.1%. |
| River barrel after betting turn | 92 | MIXED / BLUFFS PRESENT | GOOD | paired 55.4%; unpaired straight 27.2%; unpaired flush 16.3%; dry / no flush / no paired 1.1% | paired 55.4%; unpaired straight 27.2%; unpaired flush 16.3%; dry / no flush / no paired 1.1% | Bluff 28.3%; Close to nuts 20.7%; Thin value 20.7%; Practical nuts 16.3%; Low flush 5.4%; Weak straight 5.4%; Medium flush 3.3% | 28.3 | 100.0 | River barrel after betting turn had 92 shown hands. Most common river classes were Bluff 28.3%; Close to nuts 20.7%; Thin value 20.7%; Practical nuts 16.3%; Low flush 5.4%; Weak straight 5.4%; Medium flush 3.3%. Bluffs made up 28.3%. |
| Triple barrel / bet-bet-bet | 33 | MIXED / BLUFFS PRESENT | MEDIUM | paired 66.7%; unpaired straight 18.2%; unpaired flush 12.1%; dry / no flush / no paired 3.0% | paired 66.7%; unpaired straight 18.2%; unpaired flush 12.1%; dry / no flush / no paired 3.0% | Close to nuts 33.3%; Bluff 24.2%; Practical nuts 15.2%; Thin value 12.1%; Medium flush 6.1%; Weak straight 6.1%; Low flush 3.0% | 24.2 | 100.0 | Triple barrel / bet-bet-bet had 33 shown hands. Most common river classes were Close to nuts 33.3%; Bluff 24.2%; Practical nuts 15.2%; Thin value 12.1%; Medium flush 6.1%; Weak straight 6.1%; Low flush 3.0%. Bluffs made up 24.2%. |
| River raise vs bet | 15 | MOSTLY VALUE | MEDIUM | paired 53.3%; unpaired straight 33.3%; unpaired flush 13.3% | paired 53.3%; unpaired straight 33.3%; unpaired flush 13.3% | Practical nuts 60.0%; Close to nuts 13.3%; Low flush 6.7%; Weak straight 6.7%; Thin value 6.7%; Bluff 6.7% | 6.7 | 100.0 | River raise vs bet had 15 shown hands. Most common river classes were Practical nuts 60.0%; Close to nuts 13.3%; Low flush 6.7%; Weak straight 6.7%; Thin value 6.7%; Bluff 6.7%. Bluffs made up 6.7%. |
| River raise - paired board | 10 | VALUE-HEAVY | LOW | paired | paired 100.0% | Practical nuts 60.0%; Close to nuts 30.0%; Thin value 10.0% | 0.0 | 100.0 | River raise - paired board had 10 shown hands on paired boards. Practical nuts 60.0%, close to nuts/weaker boat 30.0%, thin value 10.0%, bluff 0.0%. |
| OOP turn call, river flush lead | 3 | LOW SAMPLE | LOW | unpaired flush 66.7%; paired 33.3% | unpaired flush 66.7%; paired 33.3% | Close to nuts 33.3%; Medium flush 33.3%; Low flush 33.3% | 0.0 | 100.0 | OOP turn call, river flush lead had 3 shown hands. Most common river classes were Close to nuts 33.3%; Medium flush 33.3%; Low flush 33.3%. Bluffs made up 0.0%. |
| River raise - flush completes, unpaired board | 3 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Bluff 66.7%; Low flush 33.3% | 66.7 | 100.0 | River raise - flush completes, unpaired board had 3 shown hands on unpaired rivers that completed a flush. practical nuts 0.0%, second/third nut flush 0.0%, medium flush 0.0%, low flush 33.3%, thin value 0.0%, bluff 66.7%. |
| OOP turn call, river flush lead - unpaired board | 2 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Medium flush 50.0%; Low flush 50.0% | 0.0 | 100.0 | OOP turn call, river flush lead - unpaired board had 2 shown hands on unpaired rivers that completed a flush. practical nuts 0.0%, second/third nut flush 0.0%, medium flush 50.0%, low flush 50.0%, thin value 0.0%, bluff 0.0%. |
| OOP turn call, river flush lead - paired board | 1 | LOW SAMPLE | LOW | paired | paired 100.0% | Close to nuts 100.0% | 0.0 | 100.0 | OOP turn call, river flush lead - paired board had 1 shown hands on paired boards. Practical nuts 0.0%, close to nuts/weaker boat 100.0%, thin value 0.0%, bluff 0.0%. |

## Flop and turn hand breakdown
Hands are grouped by made hand strength and draws.

| line | known_hands | read_label | confidence | flop_turn_monster_pct | flop_turn_equity_value_pct | flop_turn_one_pair_medium_pct | flop_turn_weak_air_pct | flop_turn_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Turn probe after flop checks through | 175 | RARELY AIR | GOOD | 41.1 | 53.8 | 5.1 | 0.0 | 100.0 | Turn probe after flop checks through had 175 shown hands. Strong made hands 41.1%, other value and draws 53.7%, weak hands 5.1%. |
| Turn barrel after betting flop | 137 | RARELY AIR | GOOD | 40.1 | 56.3 | 3.6 | 0.0 | 100.0 | Turn barrel after betting flop had 137 shown hands. Strong made hands 40.1%, other value and draws 56.2%, weak hands 3.6%. |
| Turn raise vs bet | 20 | RARELY AIR | LOW | 60.0 | 40.0 | 0.0 | 0.0 | 100.0 | Turn raise vs bet had 20 shown hands. Strong made hands 60.0%, other value and draws 40.0%, weak hands 0.0%. |
| Turn check-raise | 19 | RARELY AIR | LOW | 84.2 | 15.8 | 0.0 | 0.0 | 100.0 | Turn check-raise had 19 shown hands. Strong made hands 84.2%, other value and draws 15.8%, weak hands 0.0%. |
| Turn check-raise - flush completes | 1 | LOW SAMPLE | LOW | 100.0 | 0.0 | 0.0 | 0.0 | 100.0 | Turn check-raise - flush completes had 1 shown hands. Strong made hands 100.0%, other value and draws 0.0%, weak hands 0.0%. |
| Flop donk bet | 250 | RARELY AIR | GOOD | 34.4 | 56.8 | 7.6 | 1.2 | 100.0 | Flop donk bet had 250 shown hands. Strong made hands 34.4%, other value and draws 56.8%, weak hands 8.8%. |
| Flop raise vs bet | 67 | RARELY AIR | MEDIUM | 46.2 | 50.8 | 3.0 | 0.0 | 100.0 | Flop raise vs bet had 67 shown hands. Strong made hands 46.2%, other value and draws 50.8%, weak hands 3.0%. |
| Flop check-raise | 46 | RARELY AIR | MEDIUM | 28.2 | 67.5 | 4.3 | 0.0 | 100.0 | Flop check-raise had 46 shown hands. Strong made hands 28.2%, other value and draws 67.5%, weak hands 4.3%. |

## Preflop hands shown
| line | known_hands | AAxx_pct | KKxx_pct | double_suited_pct | three_plus_broadways_pct | connected_4_window_pct | read_label | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Shown PFR opens | 640 | 12.7 | 8.3 | 34.1 | 37.5 | 8.3 | OPEN RANGE SNAPSHOT | Shown PFR opens: AAxx 12.7%, KKxx 8.3%, double-suited 34.1%, 3+ broadways 37.5%, connected-window 8.3%. |
| Shown 3-bets | 197 | 23.9 | 10.2 | 39.1 | 49.2 | 8.1 | BROADWAY / AA MIX | Shown 3-bets: AAxx 23.9%, KKxx 10.2%, double-suited 39.1%, 3+ broadways 49.2%, connected-window 8.1%. |
| Shown 4-bet+ ranges | 91 | 50.5 | 7.7 | 34.1 | 53.8 | 4.4 | AA-HEAVY BUT NOT ONLY AA | Shown 4-bet+ ranges: AAxx 50.5%, KKxx 7.7%, double-suited 34.1%, 3+ broadways 53.8%, connected-window 4.4%. |

## About the sample
Only hands with known cards are included. Many successful bluffs end without a showdown, so the reported bluff share can understate how often players bluff.