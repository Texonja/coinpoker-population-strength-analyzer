# CoinPoker Population Strength - Presentation Report

This is the human-readable report. Raw CSV files are still produced for drilldown.

## Filters
- **game_filter**: plo4
- **stake_filter**: PL25
- **date_from**: none
- **date_to**: none
- **min_stack_bb**: 40.0
- **hands_analyzed_after_filters**: 5278
- **postflop_known_line_records**: 1007
- **preflop_known_line_records**: 928

## Summary - top population tells
1. Triple barrel / bet-bet-bet: still value-heavy, but not zero-bluff (24.2% bluff shown). Review blockers before overfolding.
2. River raise - paired board: shown sample is almost never bluff (0.0%). Treat as value-heavy unless you have a player-specific read.
3. Turn check-raise: shown range is mostly made/equity, not random air. Do not stack off light without strong redraws/blockers.
4. Flop check-raise: heavily value/equity driven when shown (95.7% made/equity). Naked one-pair continues are dangerous.
5. Shown 3-bets: 3-bets contain broadway/suited texture, not only AAxx (49.2% have 3+ broadways).
6. Shown 4-bet+ ranges: AAxx is a major component (50.5%), but shown range is not pure AAxx.

## River lines - exact PLO class summary
River rows use board-specific PLO classes. Check the exact class distribution and the summary sentence for each line.

| line | known_hands | read_label | confidence | river_board_family | river_board_family_distribution | river_plo_top_classes | river_bluff_pct | river_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| River probe after turn checks through | 110 | MIXED / BLUFFS PRESENT | GOOD | paired 56.4%; unpaired straight 27.3%; unpaired flush 16.4% | paired 56.4%; unpaired straight 27.3%; unpaired flush 16.4% | Thin value 34.5%; Bluff 29.1%; Practical nuts 12.7%; Close to nuts 9.1%; Low flush 7.3%; Weak straight 5.5%; Medium flush 1.8% | 29.1 | 100.0 | River probe after turn checks through: 110 known hands; main shown river classes: Thin value 34.5%; Bluff 29.1%; Practical nuts 12.7%; Close to nuts 9.1%; Low flush 7.3%; Weak straight 5.5%; Medium flush 1.8%. Bluff 29.1%. |
| River barrel after betting turn | 92 | MIXED / BLUFFS PRESENT | GOOD | paired 55.4%; unpaired straight 27.2%; unpaired flush 16.3%; dry / no flush / no paired 1.1% | paired 55.4%; unpaired straight 27.2%; unpaired flush 16.3%; dry / no flush / no paired 1.1% | Bluff 28.3%; Close to nuts 20.7%; Thin value 20.7%; Practical nuts 16.3%; Low flush 5.4%; Weak straight 5.4%; Medium flush 3.3% | 28.3 | 100.0 | River barrel after betting turn: 92 known hands; main shown river classes: Bluff 28.3%; Close to nuts 20.7%; Thin value 20.7%; Practical nuts 16.3%; Low flush 5.4%; Weak straight 5.4%; Medium flush 3.3%. Bluff 28.3%. |
| Triple barrel / bet-bet-bet | 33 | MIXED / BLUFFS PRESENT | MEDIUM | paired 66.7%; unpaired straight 18.2%; unpaired flush 12.1%; dry / no flush / no paired 3.0% | paired 66.7%; unpaired straight 18.2%; unpaired flush 12.1%; dry / no flush / no paired 3.0% | Close to nuts 33.3%; Bluff 24.2%; Practical nuts 15.2%; Thin value 12.1%; Medium flush 6.1%; Weak straight 6.1%; Low flush 3.0% | 24.2 | 100.0 | Triple barrel / bet-bet-bet: 33 known hands; main shown river classes: Close to nuts 33.3%; Bluff 24.2%; Practical nuts 15.2%; Thin value 12.1%; Medium flush 6.1%; Weak straight 6.1%; Low flush 3.0%. Bluff 24.2%. |
| River raise vs bet | 15 | MOSTLY VALUE | MEDIUM | paired 53.3%; unpaired straight 33.3%; unpaired flush 13.3% | paired 53.3%; unpaired straight 33.3%; unpaired flush 13.3% | Practical nuts 60.0%; Close to nuts 13.3%; Low flush 6.7%; Weak straight 6.7%; Thin value 6.7%; Bluff 6.7% | 6.7 | 100.0 | River raise vs bet: 15 known hands; main shown river classes: Practical nuts 60.0%; Close to nuts 13.3%; Low flush 6.7%; Weak straight 6.7%; Thin value 6.7%; Bluff 6.7%. Bluff 6.7%. |
| River raise - paired board | 10 | VALUE-HEAVY | LOW | paired | paired 100.0% | Practical nuts 60.0%; Close to nuts 30.0%; Thin value 10.0% | 0.0 | 100.0 | River raise - paired board: 10 known hands on paired boards; practical nuts/top boat 60.0%, close to nuts/weaker boat 30.0%, thin value 10.0%, bluff 0.0%. |
| OOP turn call, river flush lead | 3 | LOW SAMPLE | LOW | unpaired flush 66.7%; paired 33.3% | unpaired flush 66.7%; paired 33.3% | Close to nuts 33.3%; Medium flush 33.3%; Low flush 33.3% | 0.0 | 100.0 | OOP turn call, river flush lead: 3 known hands; main shown river classes: Close to nuts 33.3%; Medium flush 33.3%; Low flush 33.3%. Bluff 0.0%. |
| River raise - flush completes, unpaired board | 3 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Bluff 66.7%; Low flush 33.3% | 66.7 | 100.0 | River raise - flush completes, unpaired board: 3 known hands on unpaired flush-completing rivers; practical nuts 0.0%, second/third nut flush 0.0%, medium flush 0.0%, low flush 33.3%, thin value 0.0%, bluff 66.7%. |
| OOP turn call, river flush lead - unpaired board | 2 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Medium flush 50.0%; Low flush 50.0% | 0.0 | 100.0 | OOP turn call, river flush lead - unpaired board: 2 known hands on unpaired flush-completing rivers; practical nuts 0.0%, second/third nut flush 0.0%, medium flush 50.0%, low flush 50.0%, thin value 0.0%, bluff 0.0%. |
| OOP turn call, river flush lead - paired board | 1 | LOW SAMPLE | LOW | paired | paired 100.0% | Close to nuts 100.0% | 0.0 | 100.0 | OOP turn call, river flush lead - paired board: 1 known hands on paired boards; practical nuts/top boat 0.0%, close to nuts/weaker boat 100.0%, thin value 0.0%, bluff 0.0%. |

## Flop and turn lines - equity / made-hand summary
Flop and turn rows are not river-nut rankings. They show made hands, equity/value, medium one-pair hands, and weak/air.

| line | known_hands | read_label | confidence | flop_turn_monster_pct | flop_turn_equity_value_pct | flop_turn_one_pair_medium_pct | flop_turn_weak_air_pct | flop_turn_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Turn probe after flop checks through | 175 | RARELY AIR | GOOD | 41.1 | 53.8 | 5.1 | 0.0 | 100.0 | Turn probe after flop checks through: 175 known hands; made/monster 41.1%, equity/value 53.7%, weak/air 5.1%. |
| Turn barrel after betting flop | 137 | RARELY AIR | GOOD | 40.1 | 56.3 | 3.6 | 0.0 | 100.0 | Turn barrel after betting flop: 137 known hands; made/monster 40.1%, equity/value 56.2%, weak/air 3.6%. |
| Turn raise vs bet | 20 | RARELY AIR | LOW | 60.0 | 40.0 | 0.0 | 0.0 | 100.0 | Turn raise vs bet: 20 known hands; made/monster 60.0%, equity/value 40.0%, weak/air 0.0%. |
| Turn check-raise | 19 | RARELY AIR | LOW | 84.2 | 15.8 | 0.0 | 0.0 | 100.0 | Turn check-raise: 19 known hands; made/monster 84.2%, equity/value 15.8%, weak/air 0.0%. |
| Turn check-raise - flush completes | 1 | LOW SAMPLE | LOW | 100.0 | 0.0 | 0.0 | 0.0 | 100.0 | Turn check-raise - flush completes: 1 known hands; made/monster 100.0%, equity/value 0.0%, weak/air 0.0%. |
| Flop donk bet | 250 | RARELY AIR | GOOD | 34.4 | 56.8 | 7.6 | 1.2 | 100.0 | Flop donk bet: 250 known hands; made/monster 34.4%, equity/value 56.8%, weak/air 8.8%. |
| Flop raise vs bet | 67 | RARELY AIR | MEDIUM | 46.2 | 50.8 | 3.0 | 0.0 | 100.0 | Flop raise vs bet: 67 known hands; made/monster 46.2%, equity/value 50.8%, weak/air 3.0%. |
| Flop check-raise | 46 | RARELY AIR | MEDIUM | 28.2 | 67.5 | 4.3 | 0.0 | 100.0 | Flop check-raise: 46 known hands; made/monster 28.2%, equity/value 67.5%, weak/air 4.3%. |

## Preflop shown-range snapshot
| line | known_hands | AAxx_pct | KKxx_pct | double_suited_pct | three_plus_broadways_pct | connected_4_window_pct | read_label | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Shown PFR opens | 640 | 12.7 | 8.3 | 34.1 | 37.5 | 8.3 | OPEN RANGE SNAPSHOT | Shown PFR opens: AAxx 12.7%, KKxx 8.3%, double-suited 34.1%, 3+ broadways 37.5%, connected-window 8.3%. |
| Shown 3-bets | 197 | 23.9 | 10.2 | 39.1 | 49.2 | 8.1 | BROADWAY / AA MIX | Shown 3-bets: AAxx 23.9%, KKxx 10.2%, double-suited 39.1%, 3+ broadways 49.2%, connected-window 8.1%. |
| Shown 4-bet+ ranges | 91 | 50.5 | 7.7 | 34.1 | 53.8 | 4.4 | AA-HEAVY BUT NOT ONLY AA | Shown 4-bet+ ranges: AAxx 50.5%, KKxx 7.7%, double-suited 34.1%, 3+ broadways 53.8%, connected-window 4.4%. |

## Important caveat
Only known/showdown cards are measured. Bluffs that did not reach showdown are often invisible, so bluff percentages are usually understated.