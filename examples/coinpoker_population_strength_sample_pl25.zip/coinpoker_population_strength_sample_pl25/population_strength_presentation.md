# CoinPoker · Observed hand strength

Game PLO4 · Stakes PL25 · Hero Hero · All opponents at Hero's table · Stack minimum 40 bb · Dates any to any · Include BombPot False

5,278 hands match the game, stakes and dates. 3,936 hands contribute an eligible action. 1,746 of 6,399 distinct eligible actions have known cards.

Strength percentages count shown actions within a line. Some hands contribute several actions and one action can appear in several lines. Strength tables require 10 distinct hands with shown cards. Percentages round independently to one decimal.

## Preflop starting cards

| Line | Known / eligible actions | Known hands | AA | KK | Suited ace | Double suited | Any suited pair | 3+ Broadway cards | 4+ ranks in a five-rank window |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Preflop 3-bet | 197 / 617 | 197 | 47 (23.9%) | 20 (10.2%) | 97 (49.2%) | 77 (39.1%) | 184 (93.4%) | 97 (49.2%) | 16 (8.1%) |
| Preflop 4-bet or higher | 76 / 111 | 59 | 41 (53.9%) | 6 (7.9%) | 45 (59.2%) | 26 (34.2%) | 70 (92.1%) | 42 (55.3%) | 3 (3.9%) |
| First raise after a limp | 97 / 383 | 97 | 11 (11.3%) | 17 (17.5%) | 27 (27.8%) | 25 (25.8%) | 92 (94.8%) | 35 (36.1%) | 7 (7.2%) |
| First-in preflop raise | 543 / 2978 | 543 | 70 (12.9%) | 37 (6.8%) | 204 (37.6%) | 193 (35.5%) | 506 (93.2%) | 205 (37.8%) | 48 (8.8%) |

Preflop features can overlap. A hand holding two aces and two kings enters both columns.

## Flop and turn strength

| Line | Known / eligible actions | Known hands | Two pair or better | Pair or high card + draw | One pair without qualifying draw | High card without qualifying draw |
| --- | --- | --- | --- | --- | --- | --- |
| Population flop check-raise | 56 / 99 | 56 | 25 (44.6%) | 22 (39.3%) | 9 (16.1%) | 0 (0.0%) |
| Population flop donk bet | 68 / 190 | 68 | 33 (48.5%) | 21 (30.9%) | 10 (14.7%) | 4 (5.9%) |
| Population flop raise without prior check | 77 / 112 | 77 | 47 (61.0%) | 18 (23.4%) | 12 (15.6%) | 0 (0.0%) |
| Flop re-raise | 53 / 53 | 45 | 26 (49.1%) | 22 (41.5%) | 5 (9.4%) | 0 (0.0%) |
| Turn · Barrel after an unraised bet on the flop | 112 / 356 | 112 | 77 (68.8%) | 23 (20.5%) | 11 (9.8%) | 1 (0.9%) |
| Turn · Bet after the prior aggressor checks after a checked flop | 13 / 78 | 13 | 7 (53.8%) | 3 (23.1%) | 3 (23.1%) | 0 (0.0%) |
| Turn · Bet in a limped pot without prior aggression after a checked flop | 20 / 112 | 20 | 15 (75.0%) | 3 (15.0%) | 2 (10.0%) | 0 (0.0%) |
| Population turn check-raise | 22 / 44 | 22 | 21 (95.5%) | 1 (4.5%) | 0 (0.0%) | 0 (0.0%) |
| Turn · Delayed continuation bet after a checked flop | 45 / 221 | 45 | 34 (75.6%) | 5 (11.1%) | 5 (11.1%) | 1 (2.2%) |
| Turn · Follow-up after raising the flop | 11 / 25 | 11 | 8 (72.7%) | 2 (18.2%) | 1 (9.1%) | 0 (0.0%) |
| Turn · OOP probe after a checked flop | 91 / 296 | 91 | 56 (61.5%) | 25 (27.5%) | 10 (11.0%) | 0 (0.0%) |
| Population turn raise without prior check | 28 / 58 | 28 | 26 (92.9%) | 2 (7.1%) | 0 (0.0%) | 0 (0.0%) |

A qualifying draw has an immediate flush draw or at least eight distinct next cards that complete a straight using two hole cards. A completion can lose to another hand.

## River strength

| Line | Known / eligible actions | Known hands | Practical nuts | Close to nuts | Second / third nut flush | Medium flush | Low flush | Weak straight | Other made hand, top two or better | Other two pair, one pair or high card | Unbeaten (overlapping) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| River · Barrel after an unraised bet on the turn | 86 / 222 | 86 | 19 (22.1%) | 20 (23.3%) | 2 (2.3%) | 1 (1.2%) | 1 (1.2%) | 1 (1.2%) | 15 (17.4%) | 27 (31.4%) | 16 (18.6%) |
| River · Bet after the prior aggressor checks after a checked turn | 13 / 29 | 13 | 0 (0.0%) | 1 (7.7%) | 1 (7.7%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 4 (30.8%) | 7 (53.8%) | 0 (0.0%) |
| River · First postflop bet after a checked turn | 34 / 140 | 34 | 6 (17.6%) | 5 (14.7%) | 2 (5.9%) | 1 (2.9%) | 0 (0.0%) | 1 (2.9%) | 10 (29.4%) | 9 (26.5%) | 6 (17.6%) |
| Population bet-bet-bet / triple barrel shown at river | 30 / 60 | 30 | 6 (20.0%) | 11 (36.7%) | 0 (0.0%) | 0 (0.0%) | 1 (3.3%) | 1 (3.3%) | 3 (10.0%) | 8 (26.7%) | 5 (16.7%) |
| River · Delayed follow-up by the flop aggressor after a checked turn | 26 / 76 | 26 | 3 (11.5%) | 2 (7.7%) | 0 (0.0%) | 1 (3.8%) | 0 (0.0%) | 1 (3.8%) | 7 (26.9%) | 12 (46.2%) | 1 (3.8%) |
| River · OOP probe after a checked turn | 26 / 74 | 26 | 4 (15.4%) | 1 (3.8%) | 2 (7.7%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 7 (26.9%) | 12 (46.2%) | 3 (11.5%) |
| Population river raise without prior check | 14 / 43 | 14 | 6 (42.9%) | 5 (35.7%) | 1 (7.1%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 2 (14.3%) | 5 (35.7%) |
| Population river raise on paired board | 10 / 26 | 10 | 5 (50.0%) | 4 (40.0%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 1 (10.0%) | 4 (40.0%) |

Practical nuts groups the top ordinary tier with quads and straight flushes. Unbeaten checks every legal opposing pair and allows ties. Top two pair requires both highest distinct board ranks in the hand and in the best two pair. These classes describe the cards shown.

## BombPot hand strength across boards

No qualifying observations for this table.

## Card coverage by line

| Line | Known / eligible actions | Coverage | Known / eligible hands | Called or raised · known / eligible | No call or raise · known / eligible |
| --- | --- | --- | --- | --- | --- |
| FLOP_check_raise | 56 / 99 | 56.6% | 56 / 99 | 56 / 66 | 0 / 33 |
| FLOP_check_raise_paired_board | 1 / 10 | 10.0% | 1 / 10 | 1 / 3 | 0 / 7 |
| FLOP_check_raise_wet_board | 6 / 10 | 60.0% | 6 / 10 | 6 / 7 | 0 / 3 |
| FLOP_donk_bet | 68 / 190 | 35.8% | 68 / 190 | 68 / 116 | 0 / 74 |
| FLOP_raise_not_checkraise | 77 / 112 | 68.8% | 77 / 112 | 74 / 86 | 3 / 26 |
| FLOP_reraise | 53 / 53 | 100.0% | 45 / 45 | 53 / 53 | 0 / 0 |
| PFR_3bet_shown | 197 / 617 | 31.9% | 197 / 617 | 197 / 560 | 0 / 57 |
| PFR_4bet_plus_shown | 76 / 111 | 68.5% | 59 / 94 | 76 / 101 | 0 / 10 |
| PFR_iso_shown | 97 / 383 | 25.3% | 97 / 383 | 97 / 365 | 0 / 18 |
| PFR_open_shown | 543 / 2978 | 18.2% | 543 / 2978 | 543 / 2192 | 0 / 786 |
| RIVER_barrel_after_turn_bet | 86 / 222 | 38.7% | 86 / 222 | 86 / 94 | 0 / 128 |
| RIVER_bet_after_aggressor_checked_after_turn_xx | 13 / 29 | 44.8% | 13 / 29 | 13 / 13 | 0 / 16 |
| RIVER_bet_after_raised_bet_after_turn_bet | 3 / 4 | 75.0% | 3 / 4 | 3 / 3 | 0 / 1 |
| RIVER_bet_after_two_checked_streets_after_turn_xx | 34 / 140 | 24.3% | 34 / 140 | 34 / 41 | 0 / 99 |
| RIVER_bet_bet_bet | 30 / 60 | 50.0% | 30 / 60 | 30 / 32 | 0 / 28 |
| RIVER_bet_in_limped_pot_after_turn_xx | 6 / 38 | 15.8% | 6 / 38 | 6 / 7 | 0 / 31 |
| RIVER_check_raise | 4 / 6 | 66.7% | 4 / 6 | 4 / 4 | 0 / 2 |
| RIVER_delayed_followup_after_turn_xx | 26 / 76 | 34.2% | 26 / 76 | 26 / 35 | 0 / 41 |
| RIVER_followup_after_turn_raise | 2 / 7 | 28.6% | 2 / 7 | 2 / 2 | 0 / 5 |
| RIVER_oop_turn_call_flush_river_lead | 3 / 3 | 100.0% | 3 / 3 | 3 / 3 | 0 / 0 |
| RIVER_oop_turn_call_flush_river_lead_paired_board | 1 / 1 | 100.0% | 1 / 1 | 1 / 1 | 0 / 0 |
| RIVER_oop_turn_call_flush_river_lead_unpaired_board | 2 / 2 | 100.0% | 2 / 2 | 2 / 2 | 0 / 0 |
| RIVER_probe_after_turn_xx | 26 / 74 | 35.1% | 26 / 74 | 26 / 32 | 0 / 42 |
| RIVER_raise_flush_completed_paired_board | 0 / 3 | 0.0% | 0 / 3 | 0 / 0 | 0 / 3 |
| RIVER_raise_flush_completed_unpaired_board | 3 / 4 | 75.0% | 3 / 4 | 3 / 3 | 0 / 1 |
| RIVER_raise_not_checkraise | 14 / 43 | 32.6% | 14 / 43 | 14 / 15 | 0 / 28 |
| RIVER_raise_paired_board | 10 / 26 | 38.5% | 10 / 26 | 10 / 11 | 0 / 15 |
| RIVER_raise_vs_half_bet_40-70 | 3 / 9 | 33.3% | 3 / 9 | 3 / 3 | 0 / 6 |
| RIVER_raise_vs_large_pot_bet_70-115 | 7 / 17 | 41.2% | 7 / 17 | 7 / 7 | 0 / 10 |
| RIVER_raise_vs_small_bet_&lt;40 | 8 / 23 | 34.8% | 8 / 23 | 8 / 9 | 0 / 14 |
| RIVER_reraise | 5 / 6 | 83.3% | 4 / 5 | 5 / 5 | 0 / 1 |
| RIVER_reraise_vs_large_pot_raise_70-115 | 4 / 5 | 80.0% | 4 / 5 | 4 / 4 | 0 / 1 |
| RIVER_reraise_vs_small_raise_&lt;40 | 1 / 1 | 100.0% | 1 / 1 | 1 / 1 | 0 / 0 |
| TURN_barrel_after_flop_bet | 112 / 356 | 31.5% | 112 / 356 | 112 / 194 | 0 / 162 |
| TURN_bet_after_aggressor_checked_after_flop_xx | 13 / 78 | 16.7% | 13 / 78 | 13 / 36 | 0 / 42 |
| TURN_bet_after_raised_bet_after_flop_bet | 6 / 8 | 75.0% | 6 / 8 | 5 / 6 | 1 / 2 |
| TURN_bet_in_limped_pot_after_flop_xx | 20 / 112 | 17.9% | 20 / 112 | 20 / 46 | 0 / 66 |
| TURN_bet_without_active_aggressor_after_flop_xx | 1 / 1 | 100.0% | 1 / 1 | 0 / 0 | 1 / 1 |
| TURN_check_raise | 22 / 44 | 50.0% | 22 / 44 | 22 / 24 | 0 / 20 |
| TURN_check_raise_flush_completed | 1 / 5 | 20.0% | 1 / 5 | 1 / 1 | 0 / 4 |
| TURN_delayed_cbet_after_flop_xx | 45 / 221 | 20.4% | 45 / 221 | 45 / 102 | 0 / 119 |
| TURN_followup_after_flop_raise | 11 / 25 | 44.0% | 11 / 25 | 11 / 16 | 0 / 9 |
| TURN_probe_after_flop_xx | 91 / 296 | 30.7% | 91 / 296 | 91 / 171 | 0 / 125 |
| TURN_raise_not_checkraise | 28 / 58 | 48.3% | 28 / 58 | 28 / 34 | 0 / 24 |
| TURN_reraise | 8 / 9 | 88.9% | 7 / 8 | 8 / 8 | 0 / 1 |

Response columns follow the focal wager until the next raise. Card disclosure can differ sharply between called and uncalled wagers. The hidden cards and betting intentions are unknown.
