# CoinPoker Population Strength Report

The hand-level CSVs list the cards and actions behind each line.

## Filters
- **game_filter**: plo4
- **stake_filter**: PL25
- **date_from**: none
- **date_to**: none
- **min_stack_bb**: 40.0
- **hands_analyzed_after_filters**: 5278
- **postflop_known_line_records**: 894
- **preflop_known_line_records**: 913

## Highlights from shown hands
1. Bluffs made up 25.8% (8/31 shown hands) in Triple barrel / bet-bet-bet. Check the blockers in those hands when reviewing calls.
2. Bluffs made up 5.3% (1/19 shown spots across 15 hands) in River raise vs bet.
3. No bluffs in River raise - paired board (0/11 shown spots across 10 hands).
4. Made hands and draws accounted for 100.0% (22/22 shown hands) in Turn check-raise.
5. Made hands and draws accounted for 85.0% (51/60 shown spots across 59 hands) in Flop check-raise.
6. In Shown 3-bets, 49.2% (97/197 shown hands) had at least three broadway cards.

## River hand breakdown
The strength classes depend on the board. See the hand mix for each line.

| line | known_hands | read_label | confidence | river_board_family | river_board_family_distribution | river_plo_top_classes | river_bluff_pct | river_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| River probe after turn checks through | 105 | MIXED / BLUFFS PRESENT | GOOD | paired 57.1%; unpaired straight 27.6%; unpaired flush 15.2% | paired 57.1%; unpaired straight 27.6%; unpaired flush 15.2% | Thin value 36.2%; Bluff 30.5%; Practical nuts 13.3%; Close to nuts 11.4%; Second / third nut flush 4.8%; Medium flush 1.9%; Weak straight 1.9% | 30.5 | 100.0 | River probe after turn checks through had 105 shown hands. Most common river classes were Thin value 36.2%; Bluff 30.5%; Practical nuts 13.3%; Close to nuts 11.4%; Second / third nut flush 4.8%; Medium flush 1.9%; Weak straight 1.9%. Bluffs made up 30.5%. |
| River barrel after betting turn | 89 | MIXED / BLUFFS PRESENT | GOOD | paired 55.1%; unpaired straight 27.0%; unpaired flush 16.9%; dry / no flush / no paired 1.1% | paired 55.1%; unpaired straight 27.0%; unpaired flush 16.9%; dry / no flush / no paired 1.1% | Bluff 29.2%; Practical nuts 22.5%; Close to nuts 22.5%; Thin value 20.2%; Second / third nut flush 2.2%; Medium flush 1.1%; Low flush 1.1%; Weak straight 1.1% | 29.2 | 100.0 | River barrel after betting turn had 89 shown hands. Most common river classes were Bluff 29.2%; Practical nuts 22.5%; Close to nuts 22.5%; Thin value 20.2%; Second / third nut flush 2.2%; Medium flush 1.1%; Low flush 1.1%; Weak straight 1.1%. Bluffs made up 29.2%. |
| Triple barrel / bet-bet-bet | 31 | MIXED / BLUFFS PRESENT | MEDIUM | paired 67.7%; unpaired straight 16.1%; unpaired flush 12.9%; dry / no flush / no paired 3.2% | paired 67.7%; unpaired straight 16.1%; unpaired flush 12.9%; dry / no flush / no paired 3.2% | Close to nuts 35.5%; Bluff 25.8%; Practical nuts 19.4%; Thin value 12.9%; Low flush 3.2%; Weak straight 3.2% | 25.8 | 100.0 | Triple barrel / bet-bet-bet had 31 shown hands. Most common river classes were Close to nuts 35.5%; Bluff 25.8%; Practical nuts 19.4%; Thin value 12.9%; Low flush 3.2%; Weak straight 3.2%. Bluffs made up 25.8%. |
| River raise vs bet | 19 | MOSTLY VALUE | MEDIUM | paired 47.4%; unpaired straight 36.8%; unpaired flush 15.8% | paired 47.4%; unpaired straight 36.8%; unpaired flush 15.8% | Practical nuts 57.9%; Close to nuts 26.3%; Second / third nut flush 5.3%; Thin value 5.3%; Bluff 5.3% | 5.3 | 100.0 | River raise vs bet had 19 shown hands. Most common river classes were Practical nuts 57.9%; Close to nuts 26.3%; Second / third nut flush 5.3%; Thin value 5.3%; Bluff 5.3%. Bluffs made up 5.3%. |
| River raise - paired board | 11 | VALUE-HEAVY | LOW | paired | paired 100.0% | Practical nuts 54.5%; Close to nuts 36.4%; Thin value 9.1% | 0.0 | 100.0 | River raise - paired board had 11 shown hands on paired boards. Practical nuts 54.5%, close to nuts/weaker boat 36.4%, thin value 9.1%, bluff 0.0%. |
| River raise - flush completes, unpaired board | 4 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Bluff 50.0%; Practical nuts 25.0%; Second / third nut flush 25.0% | 50.0 | 100.0 | River raise - flush completes, unpaired board had 4 shown hands on unpaired rivers that completed a flush. practical nuts 25.0%, second/third nut flush 25.0%, medium flush 0.0%, low flush 0.0%, thin value 0.0%, bluff 50.0%. |
| OOP turn call, river flush lead | 3 | LOW SAMPLE | LOW | unpaired flush 66.7%; paired 33.3% | unpaired flush 66.7%; paired 33.3% | Practical nuts 33.3%; Close to nuts 33.3%; Second / third nut flush 33.3% | 0.0 | 100.0 | OOP turn call, river flush lead had 3 shown hands. Most common river classes were Practical nuts 33.3%; Close to nuts 33.3%; Second / third nut flush 33.3%. Bluffs made up 0.0%. |
| OOP turn call, river flush lead - unpaired board | 2 | LOW SAMPLE | LOW | unpaired flush | unpaired flush 100.0% | Practical nuts 50.0%; Second / third nut flush 50.0% | 0.0 | 100.0 | OOP turn call, river flush lead - unpaired board had 2 shown hands on unpaired rivers that completed a flush. practical nuts 50.0%, second/third nut flush 50.0%, medium flush 0.0%, low flush 0.0%, thin value 0.0%, bluff 0.0%. |
| OOP turn call, river flush lead - paired board | 1 | LOW SAMPLE | LOW | paired | paired 100.0% | Close to nuts 100.0% | 0.0 | 100.0 | OOP turn call, river flush lead - paired board had 1 shown hands on paired boards. Practical nuts 0.0%, close to nuts/weaker boat 100.0%, thin value 0.0%, bluff 0.0%. |

## Flop and turn hand breakdown
Hands are grouped by made hand strength and draws.

| line | known_hands | read_label | confidence | flop_turn_monster_pct | flop_turn_equity_value_pct | flop_turn_one_pair_medium_pct | flop_turn_weak_air_pct | flop_turn_total_pct | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Turn probe after flop checks through | 170 | RARELY AIR | GOOD | 40.6 | 47.0 | 11.8 | 0.6 | 100.0 | Turn probe after flop checks through had 170 shown hands. Strong made hands 40.6%, other value and draws 47.1%, weak hands 12.4%. |
| Turn barrel after betting flop | 118 | RARELY AIR | GOOD | 39.0 | 50.9 | 9.3 | 0.8 | 100.0 | Turn barrel after betting flop had 118 shown hands. Strong made hands 39.0%, other value and draws 50.9%, weak hands 10.1%. |
| Turn raise vs bet | 36 | RARELY AIR | MEDIUM | 63.9 | 36.1 | 0.0 | 0.0 | 100.0 | Turn raise vs bet had 36 shown hands. Strong made hands 63.9%, other value and draws 36.1%, weak hands 0.0%. |
| Turn check-raise | 22 | RARELY AIR | LOW | 81.9 | 18.1 | 0.0 | 0.0 | 100.0 | Turn check-raise had 22 shown hands. Strong made hands 81.9%, other value and draws 18.1%, weak hands 0.0%. |
| Turn check-raise - flush completes | 1 | LOW SAMPLE | LOW | 100.0 | 0.0 | 0.0 | 0.0 | 100.0 | Turn check-raise - flush completes had 1 shown hands. Strong made hands 100.0%, other value and draws 0.0%, weak hands 0.0%. |
| Flop raise vs bet | 126 | RARELY AIR | GOOD | 38.1 | 48.4 | 13.5 | 0.0 | 100.0 | Flop raise vs bet had 126 shown hands. Strong made hands 38.1%, other value and draws 48.4%, weak hands 13.5%. |
| Flop donk bet | 68 | VALUE + EQUITY | MEDIUM | 25.0 | 54.4 | 14.7 | 5.9 | 100.0 | Flop donk bet had 68 shown hands. Strong made hands 25.0%, other value and draws 54.4%, weak hands 20.6%. |
| Flop check-raise | 60 | RARELY AIR | MEDIUM | 26.7 | 58.3 | 15.0 | 0.0 | 100.0 | Flop check-raise had 60 shown hands. Strong made hands 26.7%, other value and draws 58.3%, weak hands 15.0%. |

## Preflop hands shown
| line | known_hands | AAxx_pct | KKxx_pct | double_suited_pct | three_plus_broadways_pct | connected_4_window_pct | read_label | plain_english_summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Shown PFR opens | 640 | 12.7 | 8.3 | 34.1 | 37.5 | 8.3 | OPEN RANGE SNAPSHOT | Shown PFR opens: AAxx 12.7%, KKxx 8.3%, double-suited 34.1%, 3+ broadways 37.5%, connected-window 8.3%. |
| Shown 3-bets | 197 | 23.9 | 10.2 | 39.1 | 49.2 | 8.1 | BROADWAY / AA MIX | Shown 3-bets: AAxx 23.9%, KKxx 10.2%, double-suited 39.1%, 3+ broadways 49.2%, connected-window 8.1%. |
| Shown 4-bet+ ranges | 76 | 53.9 | 7.9 | 34.2 | 55.3 | 3.9 | AA-HEAVY BUT NOT ONLY AA | Shown 4-bet+ ranges: AAxx 53.9%, KKxx 7.9%, double-suited 34.2%, 3+ broadways 55.3%, connected-window 3.9%. |

## Card coverage by line

Eligible and classified action records after filters. A single action can match several lines.

| line_id | eligible_actions | known_records | known_pct |
| --- | --- | --- | --- |
| FLOP_check_raise | 103 | 60 | 58.3 |
| FLOP_check_raise_paired_board | 10 | 1 | 10.0 |
| FLOP_check_raise_wet_board | 2 | 0 | 0.0 |
| FLOP_donk_bet | 190 | 68 | 35.8 |
| FLOP_raise_not_checkraise | 161 | 126 | 78.3 |
| PFR_3bet_shown | 617 | 197 | 31.9 |
| PFR_4bet_plus_shown | 111 | 76 | 68.5 |
| PFR_open_shown | 3361 | 640 | 19.0 |
| RIVER_barrel_after_turn_bet | 226 | 89 | 39.4 |
| RIVER_bet_bet_bet | 62 | 31 | 50.0 |
| RIVER_check_raise | 6 | 4 | 66.7 |
| RIVER_oop_turn_call_flush_river_lead | 3 | 3 | 100.0 |
| RIVER_oop_turn_call_flush_river_lead_paired_board | 1 | 1 | 100.0 |
| RIVER_oop_turn_call_flush_river_lead_unpaired_board | 2 | 2 | 100.0 |
| RIVER_probe_after_turn_xx | 357 | 105 | 29.4 |
| RIVER_raise_flush_completed_paired_board | 3 | 0 | 0.0 |
| RIVER_raise_flush_completed_unpaired_board | 5 | 4 | 80.0 |
| RIVER_raise_not_checkraise | 49 | 19 | 38.8 |
| RIVER_raise_paired_board | 28 | 11 | 39.3 |
| RIVER_raise_vs_half_bet_40-70 | 9 | 3 | 33.3 |
| RIVER_raise_vs_large_pot_bet_70-115 | 18 | 8 | 44.4 |
| RIVER_raise_vs_overbet_>115 | 5 | 4 | 80.0 |
| RIVER_raise_vs_small_bet_<40 | 23 | 8 | 34.8 |
| TURN_barrel_after_flop_bet | 364 | 118 | 32.4 |
| TURN_check_raise | 44 | 22 | 50.0 |
| TURN_check_raise_flush_completed | 5 | 1 | 20.0 |
| TURN_probe_after_flop_xx | 708 | 170 | 24.0 |
| TURN_raise_not_checkraise | 67 | 36 | 53.7 |

## About the sample
Only hands with known cards are included. Many successful bluffs end without a showdown, so the reported bluff share can understate how often players bluff.